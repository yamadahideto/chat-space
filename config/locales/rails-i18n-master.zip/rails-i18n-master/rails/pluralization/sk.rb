require 'rails_i18n/common_pluralizations/west_slavic'

::RailsI18n::Pluralization::WestSlavic.with_locale(:sk)