require 'rails_i18n/common_pluralizations/east_slavic'

::RailsI18n::Pluralization::EastSlavic.with_locale(:bs)