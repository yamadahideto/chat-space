require 'rails_i18n/common_pluralizations/one_other'

::RailsI18n::Pluralization::OneOther.with_locale(:nl)