require 'rails_i18n/common_pluralizations/one_with_zero_other'

::RailsI18n::Pluralization::OneWithZeroOther.with_locale(:ln)