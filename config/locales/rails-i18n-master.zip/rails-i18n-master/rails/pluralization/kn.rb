require 'rails_i18n/common_pluralizations/other'

::RailsI18n::Pluralization::Other.with_locale(:kn)